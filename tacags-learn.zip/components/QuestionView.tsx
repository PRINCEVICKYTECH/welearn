import React, { useEffect, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ClassLevel, Subject } from '../types';
import { generatePastQuestions } from '../services/gemini';
import { ArrowLeft, Download, Loader2, RefreshCw } from 'lucide-react';

interface QuestionViewProps {
  subject: Subject;
  classLevel: ClassLevel;
  onBack: () => void;
}

export const QuestionView: React.FC<QuestionViewProps> = ({ subject, classLevel, onBack }) => {
  const [content, setContent] = useState<string>("");
  const [loading, setLoading] = useState(true);

  const fetchQuestions = async () => {
    setLoading(true);
    const questions = await generatePastQuestions(subject, classLevel);
    setContent(questions);
    setLoading(false);
  };

  useEffect(() => {
    fetchQuestions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subject, classLevel]);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700">
       <div className="flex items-center justify-between mb-6">
         <div className="flex items-center gap-3">
            <button 
              onClick={onBack}
              className="p-2 -ml-2 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition-colors no-print"
            >
              <ArrowLeft className="h-6 w-6" />
            </button>
            <div>
              <div className="flex items-center gap-2 text-sm text-emerald-600 font-semibold mb-1">
                <span>{classLevel}</span>
                <span>•</span>
                <span>{subject.name}</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-slate-900 leading-tight">Exam Practice</h1>
            </div>
         </div>
         
         {!loading && (
           <div className="flex gap-2 no-print">
             <button 
                onClick={fetchQuestions}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors"
             >
               <RefreshCw className="h-4 w-4" />
               <span className="hidden sm:inline">New Questions</span>
             </button>
             <button 
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
             >
               <Download className="h-4 w-4" />
               <span className="hidden sm:inline">Save PDF</span>
             </button>
           </div>
         )}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[400px] bg-white rounded-2xl border border-slate-200 shadow-sm p-8 text-center space-y-6">
           <div className="relative">
             <div className="absolute inset-0 bg-yellow-100 rounded-full animate-ping opacity-75"></div>
             <div className="relative bg-white p-4 rounded-full border-2 border-yellow-100">
                <Loader2 className="h-8 w-8 text-yellow-600 animate-spin" />
             </div>
           </div>
           <div className="space-y-2">
             <h3 className="text-lg font-semibold text-slate-800">Generating Exam Questions...</h3>
             <p className="text-slate-500 max-w-md mx-auto">
               Curating WAEC/NECO standard questions for <strong>{subject.name}</strong>. Please wait while we access the archives.
             </p>
           </div>
        </div>
      ) : (
        <article className="prose prose-slate prose-lg md:prose-xl max-w-none bg-white p-8 md:p-12 rounded-2xl shadow-sm border border-slate-200">
          <ReactMarkdown 
            remarkPlugins={[remarkGfm]}
            components={{
              h1: ({node, ...props}) => <h1 className="text-3xl font-bold text-slate-900 mb-6 pb-2 border-b-2 border-slate-100" {...props} />,
              h2: ({node, ...props}) => <h2 className="text-xl font-bold text-emerald-800 bg-emerald-50 px-4 py-2 rounded-lg mt-8 mb-4 border-l-4 border-emerald-500" {...props} />,
              h3: ({node, ...props}) => <h3 className="text-lg font-semibold text-slate-800 mt-6 mb-3" {...props} />,
              p: ({node, ...props}) => <p className="mb-4 text-slate-700 leading-relaxed" {...props} />,
              ul: ({node, ...props}) => <ul className="list-none pl-0 space-y-3" {...props} />,
              ol: ({node, ...props}) => <ol className="list-decimal pl-6 space-y-4 font-medium text-slate-800" {...props} />,
              li: ({node, ...props}) => <li className="pl-1" {...props} />,
              strong: ({node, ...props}) => <strong className="font-bold text-slate-900" {...props} />,
            }}
          >
            {content}
          </ReactMarkdown>
        </article>
      )}
    </div>
  );
};
